# assets/handler.py

import json

def handler(event, context):
    # Log the incoming event
    print(f"Received event: {json.dumps(event)}")

    message = "Hello from Python Lambda!"
    return {
        "statusCode": 200,
        "body": json.dumps(message)
    }
