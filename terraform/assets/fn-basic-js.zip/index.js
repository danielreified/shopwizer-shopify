exports.handler = async (event) => {
    // Log the received event
    console.log(`Received event: ${JSON.stringify(event, null, 2)}`);
    
    const message = 'Hello from Lambda!';
    
    return {
        statusCode: 200,
        body: JSON.stringify(message)
    };
};